#ifndef DEFS_H
#define DEFS_H

#define FPS 60
#define ACCELX 0
#define ACCELY 0
#define SCREEN_W 1600
#define SCREEN_H 600
#define STAT_SOL 0
#define STAT_AIR 1
typedef int bool;
enum { false, true };

#endif
