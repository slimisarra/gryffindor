#ifndef JEU_H
#define JEU_H

#include <SDL/SDL.h>

int jouer(SDL_Surface * ecran);

#endif
